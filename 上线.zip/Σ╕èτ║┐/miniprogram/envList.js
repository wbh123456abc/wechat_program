const envList = [{"envId":"cloud1-0glb2gl912b87655","alias":"cloud1"}]
const isMac = true
module.exports = {
    envList,
    isMac
}